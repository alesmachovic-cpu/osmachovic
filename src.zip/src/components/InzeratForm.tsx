"use client";

import { useState, useRef, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import type { TypNehnutelnosti, StavNehnutelnosti } from "@/lib/database.types";
import { KRAJE } from "@/lib/database.types";

/* ── Design tokens ── */
const s = {
  card: { background: "#fff", borderRadius: "16px", padding: "24px", marginBottom: "12px", boxShadow: "0 1px 3px rgba(0,0,0,0.04), 0 1px 2px rgba(0,0,0,0.06)" } as React.CSSProperties,
  input: { width: "100%", padding: "10px 14px", background: "#F9FAFB", border: "1.5px solid #E5E7EB", borderRadius: "10px", fontSize: "14px", color: "#374151", outline: "none", transition: "border-color 0.15s" } as React.CSSProperties,
  select: { width: "100%", padding: "10px 14px", background: "#F9FAFB", border: "1.5px solid #E5E7EB", borderRadius: "10px", fontSize: "14px", color: "#374151", outline: "none", cursor: "pointer", appearance: "none" as const, backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='10' height='6' viewBox='0 0 10 6' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1L5 5L9 1' stroke='%239CA3AF' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "right 12px center", paddingRight: "32px" } as React.CSSProperties,
  label: { fontSize: "12px", fontWeight: "500", color: "#6B7280", marginBottom: "6px", display: "block" } as React.CSSProperties,
  title: { fontSize: "15px", fontWeight: "600", color: "#374151", marginBottom: "18px", letterSpacing: "-0.01em" } as React.CSSProperties,
  g2: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" } as React.CSSProperties,
  g3: { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "12px" } as React.CSSProperties,
};

function Tog({ on, set, label }: { on: boolean; set: (v: boolean) => void; label: string }) {
  return (
    <label style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "6px 0", cursor: "pointer" }}>
      <span style={{ fontSize: "13px", color: "#374151" }}>{label}</span>
      <div onClick={() => set(!on)} style={{ width: "40px", height: "24px", borderRadius: "12px", background: on ? "#3B82F6" : "#D1D5DB", position: "relative", transition: "background 0.15s", flexShrink: 0 }}>
        <div style={{ width: "20px", height: "20px", borderRadius: "10px", background: "#fff", position: "absolute", top: "2px", left: on ? "18px" : "2px", transition: "left 0.15s", boxShadow: "0 1px 2px rgba(0,0,0,0.15)" }} />
      </div>
    </label>
  );
}

/* ── Progress bar ── */
function Progress({ active, text }: { active: boolean; text: string }) {
  if (!active) return null;
  return (
    <div style={{ padding: "12px 20px", background: "#EFF6FF", borderRadius: "10px", marginBottom: "12px", display: "flex", alignItems: "center", gap: "10px" }}>
      <div style={{ width: "16px", height: "16px", border: "2px solid #93C5FD", borderTopColor: "#3B82F6", borderRadius: "50%", animation: "spin 0.6s linear infinite", flexShrink: 0 }} />
      <span style={{ fontSize: "13px", fontWeight: "500", color: "#1D4ED8" }}>{text}</span>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}@keyframes bounce{0%,80%,100%{transform:scale(.6);opacity:.4}40%{transform:scale(1);opacity:1}}`}</style>
    </div>
  );
}

const OKRESY: Record<string, string[]> = {
  "Bratislavský kraj": ["Bratislava I","Bratislava II","Bratislava III","Bratislava IV","Bratislava V","Malacky","Pezinok","Senec"],
  "Trnavský kraj": ["Dunajská Streda","Galanta","Hlohovec","Piešťany","Senica","Skalica","Trnava"],
  "Trenčínsky kraj": ["Bánovce nad Bebravou","Ilava","Myjava","Nové Mesto nad Váhom","Partizánske","Považská Bystrica","Prievidza","Púchov","Trenčín"],
  "Nitriansky kraj": ["Komárno","Levice","Nitra","Nové Zámky","Šaľa","Topoľčany","Zlaté Moravce"],
  "Žilinský kraj": ["Bytča","Čadca","Dolný Kubín","Kysucké Nové Mesto","Liptovský Mikuláš","Martin","Námestovo","Ružomberok","Turčianske Teplice","Tvrdošín","Žilina"],
  "Banskobystrický kraj": ["Banská Bystrica","Banská Štiavnica","Brezno","Detva","Krupina","Lučenec","Poltár","Revúca","Rimavská Sobota","Veľký Krtíš","Zvolen","Žarnovica","Žiar nad Hronom"],
  "Prešovský kraj": ["Bardejov","Humenné","Kežmarok","Levoča","Medzilaborce","Poprad","Prešov","Sabinov","Snina","Stará Ľubovňa","Stropkov","Svidník","Vranov nad Topľou"],
  "Košický kraj": ["Gelnica","Košice I","Košice II","Košice III","Košice IV","Košice-okolie","Michalovce","Rožňava","Sobrance","Spišská Nová Ves","Trebišov"],
};

const PORTALY = [
  { key: "nehnutelnosti_sk", label: "Nehnutelnosti.sk" },
  { key: "topreality", label: "TopReality.sk" },
  { key: "bazos", label: "Bazos.sk" },
  { key: "reality_sk", label: "Reality.sk" },
  { key: "realsoft", label: "RealSoft" },
  { key: "facebook", label: "Facebook" },
];

const defaultForm = {
  // Základné
  nazov: "", typ: "" as TypNehnutelnosti, lokalita: "", cena: "", kategoria: "",
  popis: "", url_inzercia: "", intro: "", text_popis: "", lv_text: "",
  // Zobrazenie
  zobrazovat_cenu: true, zobrazovat_mapu: true, zobrazovat_hypoteku: true,
  so_zmluvou: false, projekt: false, specialne_oznacenie: "", seo_keywords: "",
  // Lokácia
  stat: "Slovensko", kraj: "", okres: "", obec: "", ulica_verejna: "", ulica_privatna: "",
  makler: "Aleš Machovič", interne_id: "",
  // Rozšírené vlastnosti
  plocha: "", uzitkova_plocha: "", zastavana_plocha: "", podlahova_plocha: "", skladova_plocha: "",
  stav: "", energeticky_certifikat: "", energeticka_narocnost: "",
  typ_budovy: "", typ_vybavy: "",
  // Priestory
  poschodie: "", pozicia: "", celkova_plocha: "", izby: "",
  // Toggles — priestory
  balkon: false, loggia: false, terasa: false, garaz: false, pivnica: false,
  verejne_parkovanie: false, sukromne_parkovanie: false,
  spajza: false, sklad_toggle: false, dielna: false, vytah: false,
  // Detail priestorov
  balkon_plocha: "", loggia_plocha: "", loggia_pocet: "", terasa_plocha: "",
  pivnica_plocha: "", pivnica_pocet: "", parkovanie_typ: "",
  // Roky
  rok_vystavby: "", rok_rekonstrukcie: "", rok_kolaudacie: "",
  poschodia_vyssie: "", poschodia_nizsie: "",
  // Vykurovanie
  vykurovanie: { centralne: false, podlahove: false, lokalne: false, ine: false, kozub: false, klimatizacia: false, emitory: false } as Record<string, boolean>,
  // Pripojenie
  pripojenie: { telefon: false, internet: false, satelit: false, kablova_tv: false, opticka_siet: false, ine: false } as Record<string, boolean>,
  // Ďalšie
  orientacia: "", inzinierske_siete: false,
  typ_ceny: "", tagy: "", vlastnictvo: "", text_k_cene: "", cena_za_energie: "",
  exkluzivne: false, url_virtualka: "", vhodne_pre_studentov: false,
  video_url: "",
  // Náklady a právne
  mesacne_naklady: "", naklady_detail: "", pravne_vady: "",
  // Privátne
  provizia_hodnota: "", provizia_typ: "EUR", poznamka_interna: "",
  // Export
  export_portaly: { nehnutelnosti_sk: false, topreality: false, bazos: false, reality_sk: false, realsoft: false, facebook: false } as Record<string, boolean>,
};

export default function InzeratForm({ onSaved, onCancel, prefilledData }: { onSaved?: () => void; onCancel?: () => void; prefilledData?: Record<string, unknown> | null } = {}) {
  const [f, setF] = useState(() => {
    if (!prefilledData) return defaultForm;
    // Prefill z náberu
    const d = prefilledData;
    return {
      ...defaultForm,
      typ: (String(d.typ_nehnutelnosti || "") || defaultForm.typ) as TypNehnutelnosti,
      kraj: String(d.kraj || defaultForm.kraj),
      okres: String(d.okres || defaultForm.okres),
      obec: String(d.obec || defaultForm.obec),
      lokalita: String(d.obec || defaultForm.lokalita),
      plocha: String(d.plocha || defaultForm.plocha),
      cena: String(d.predajna_cena || defaultForm.cena),
    };
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [generating, setGenerating] = useState(false);
  const [parsingLV, setParsingLV] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [lvParsed, setLvParsed] = useState<Record<string, string> | null>(null);
  const [dropOver, setDropOver] = useState(false);
  const [photos, setPhotos] = useState<{ name: string; url: string; size: number }[]>([]);
  const [docs, setDocs] = useState<{ name: string; type: string; size: number; text?: string }[]>([]);
  const [processingDoc, setProcessingDoc] = useState(-1);
  const [uploadingFile, setUploadingFile] = useState("");
  const aiRef = useRef<HTMLDivElement>(null);
  const dropRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const prevent = (e: DragEvent) => { e.preventDefault(); e.stopPropagation(); };
    document.addEventListener("dragover", prevent);
    document.addEventListener("drop", prevent);
    return () => { document.removeEventListener("dragover", prevent); document.removeEventListener("drop", prevent); };
  }, []);

  function set(k: string, v: string | boolean | number) { setF(p => ({ ...p, [k]: v })); }
  function setPr(k: string, v: boolean) { setF(p => ({ ...p, pripojenie: { ...p.pripojenie, [k]: v } })); }
  function setVyk(k: string, v: boolean) { setF(p => ({ ...p, vykurovanie: { ...p.vykurovanie, [k]: v } })); }
  function setEx(k: string, v: boolean) { setF(p => ({ ...p, export_portaly: { ...p.export_portaly, [k]: v } })); }
  function toggleAllPortals() {
    const allOn = PORTALY.every(p => f.export_portaly[p.key]);
    const next: Record<string, boolean> = {};
    PORTALY.forEach(p => next[p.key] = !allOn);
    setF(p => ({ ...p, export_portaly: next }));
  }

  function toBataCena(raw: string): string {
    const n = parseInt(raw.replace(/\s/g, ""), 10);
    if (!n || n <= 0) return raw;
    if (n < 1000) return String(Math.round(n / 100) * 100 - 1);
    return String(Math.round(n / 1000) * 1000 - 100);
  }

  /* ── Universal file handler ── */
  /* ── Detekcia typu dokumentu ── */
  function detectDocType(text: string, fileName: string): "lv" | "posudok" | "zmluva" | "dokument" {
    const lower = text.toLowerCase();
    const nameLower = fileName.toLowerCase();
    // LV musí mať viaceré špecifické znaky naraz
    const lvSignals = [
      "list vlastníctva", "lv č.", "katastrálny úrad", "katastrálne územie",
      "časť a", "časť b", "časť c", "správa katastra", "okres:", "obec:",
      "parcely registra", "spoluvlastnícky podiel", "druh pozemku"
    ];
    const lvScore = lvSignals.filter(w => lower.includes(w)).length;
    // Znalecký posudok
    const posudokSignals = [
      "znalecký posudok", "znalec", "všeobecná hodnota", "ohodnotenie",
      "technická hodnota", "východisková hodnota", "koeficient", "opotrebenie",
      "podlahová plocha", "obhliadka", "zadávateľ", "výpočet hodnoty",
      "porovnávacia metóda", "prílohy k posudku"
    ];
    const posudokScore = posudokSignals.filter(w => lower.includes(w)).length;
    // Zmluva
    const zmluvaSignals = [
      "kúpna zmluva", "zmluva o prevode", "predávajúci", "kupujúci",
      "zmluvné strany", "predmet zmluvy", "kúpna cena", "zmluva o budúcej",
      "nájomná zmluva", "prenajímateľ", "nájomca", "nadobúdací doklad"
    ];
    const zmluvaScore = zmluvaSignals.filter(w => lower.includes(w)).length;
    // Aj názov súboru pomáha
    if (nameLower.includes("posudok") || nameLower.includes("znalec")) return "posudok";
    if (nameLower.includes("zmluva") || nameLower.includes("nadobud") || nameLower.includes("doklad")) return "zmluva";
    if (nameLower.includes("lv") || nameLower.includes("list vlastn")) return "lv";
    // Rozhodnutie podľa skóre — LV vyžaduje silnejšiu zhodu (min 3)
    if (lvScore >= 3 && lvScore > posudokScore) return "lv";
    if (posudokScore >= 2) return "posudok";
    if (zmluvaScore >= 2) return "zmluva";
    if (lvScore >= 2) return "lv";
    return "dokument";
  }

  function handleFiles(files: FileList | File[]) {
    Array.from(files).forEach(file => {
      const ext = file.name.split(".").pop()?.toLowerCase() || "";
      const isImg = file.type.startsWith("image/") || ["jpg","jpeg","png","webp","gif","heic"].includes(ext);
      const isPdf = file.type === "application/pdf" || ext === "pdf";

      if (isImg) {
        setPhotos(prev => [...prev, { name: file.name, url: URL.createObjectURL(file), size: file.size }]);
      } else if (isPdf) {
        setUploadingFile(file.name);
        setParsingLV(true);
        // Krok 1: Extrahuj text z PDF
        const fd = new FormData(); fd.append("file", file);
        // Súčasne priprav base64 pre priame AI spracovanie
        const base64Promise = file.arrayBuffer().then(buf => {
          const bytes = new Uint8Array(buf);
          let binary = "";
          for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
          return btoa(binary);
        });
        globalThis.fetch("/api/parse-pdf", { method: "POST", body: fd })
          .then(r => r.json())
          .then(async (data) => {
            if (data.text) {
              const docType = detectDocType(data.text, file.name);
              if (docType === "lv") {
                set("lv_text", data.text); handleParseLV(data.text);
              } else {
                const typeLabel = docType === "posudok" ? "Znalecký posudok" : docType === "zmluva" ? "Zmluva" : "PDF";
                setDocs(prev => [...prev, { name: file.name, type: typeLabel, size: file.size, text: data.text }]);
                // Auto-spracovanie — posielame base64 PDF priamo do AI pre lepšiu kvalitu
                if (docType === "posudok" || docType === "zmluva") {
                  try {
                    const b64 = await base64Promise;
                    const res = await globalThis.fetch("/api/parse-lv", {
                      method: "POST", headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ lv_text: data.text, doc_type: docType, pdf_base64: b64 }),
                    });
                    const parsed = await res.json();
                    if (!parsed.error) {
                      fillFormFromAI(parsed);
                      setDocs(prev => prev.map(d => d.name === file.name ? { ...d, type: `${typeLabel} ✓` } : d));
                    }
                  } catch { /* manuálne cez ⚡AI tlačidlo */ }
                }
                setParsingLV(false);
              }
            } else { setDocs(prev => [...prev, { name: file.name, type: "PDF", size: file.size }]); setParsingLV(false); }
            setUploadingFile("");
          })
          .catch(() => { setDocs(prev => [...prev, { name: file.name, type: "PDF", size: file.size }]); setParsingLV(false); setUploadingFile(""); });
      } else if (["txt","doc","docx"].includes(ext)) {
        const reader = new FileReader();
        reader.onload = ev => {
          const t = ev.target?.result;
          if (typeof t === "string" && t.trim()) {
            const docType = detectDocType(t, file.name);
            if (docType === "lv") { set("lv_text", t); handleParseLV(t); }
            else { setDocs(prev => [...prev, { name: file.name, type: docType === "posudok" ? "Znalecký posudok" : docType === "zmluva" ? "Zmluva" : ext.toUpperCase(), size: file.size, text: t }]); }
          }
        };
        reader.readAsText(file);
      } else {
        setDocs(prev => [...prev, { name: file.name, type: ext.toUpperCase(), size: file.size }]);
      }
    });
  }

  function handleDrop(e: React.DragEvent) { e.preventDefault(); e.stopPropagation(); setDropOver(false); if (e.dataTransfer.files?.length) handleFiles(e.dataTransfer.files); }

  /* ── Mapovanie typu z AI na hodnotu selectu ── */
  const typMap: Record<string, string> = {
    "byt": "3-izbovy-byt", "1-izbový byt": "1-izbovy-byt", "2-izbový byt": "2-izbovy-byt",
    "3-izbový byt": "3-izbovy-byt", "4-izbový byt": "4-izbovy-byt", "5-izbový byt": "5-izbovy-byt",
    "garsónka": "garsonka", "dvojgarsónka": "dvojgarsonka", "mezonet": "mezonet", "loft": "loft",
    "dom": "rodinny-dom", "rodinný dom": "rodinny-dom", "rodinny dom": "rodinny-dom",
    "chata": "chata", "vidiecky dom": "vidiecky-dom", "zrub": "zrub",
    "pozemok": "stavebny-pozemok", "záhrada": "zahrada", "orná pôda": "orna-poda", "les": "les",
    "garáž": "komercny-objekt", "garaz": "komercny-objekt",
    "komerčné": "komercny-objekt", "komercne": "komercny-objekt",
    "kancelárie": "kancelarie", "sklad": "sklad", "reštaurácia": "restauracia",
  };
  const materialMap: Record<string, string> = {
    "tehla": "tehlova", "panel": "panelova", "skelet": "zmiešaná",
    "drevo": "drevena", "ine": "ina",
  };
  const stavMap: Record<string, string> = {
    "novostavba": "novostavba", "povodny-stav": "povodny-stav", "pôvodný stav": "povodny-stav",
    "uplne-prerobeny": "uplne-prerobeny", "úplne prerobený": "uplne-prerobeny",
    "ciastocne-prerobeny": "ciastocne-prerobeny", "čiastočne prerobený": "ciastocne-prerobeny",
    "vo-vystavbe": "vo-vystavbe", "vo výstavbe": "vo-vystavbe",
  };

  /* ── Spoločná funkcia na vyplnenie formulára z AI dát ── */
  function fillFormFromAI(data: Record<string, string>, lvText?: string) {
    // Zostavenie prehľadu extrahovaných dát
    const filled: Record<string, string> = {};
    if (data.obec) filled["Obec"] = data.obec;
    if (data.katastralneUzemie) filled["k.ú."] = data.katastralneUzemie;
    if (data.okres) filled["Okres"] = data.okres;
    if (data.kraj) filled["Kraj"] = data.kraj;
    if (data.ulica) filled["Ulica"] = data.ulica;
    if (data.cena) filled["Cena"] = data.cena + " €";
    if (data.plocha) filled["Plocha"] = data.plocha + " m²";
    if (data.uzitkova_plocha) filled["Úžitková"] = data.uzitkova_plocha + " m²";
    if (data.vlastnictvo) filled["Vlastníctvo"] = data.vlastnictvo;
    if (data.typ) filled["Typ"] = data.typ;
    if (data.stav) filled["Stav"] = data.stav;
    if (data.material) filled["Materiál"] = data.material;
    if (data.kategoria) filled["Kategória"] = data.kategoria === "predaj" ? "Predaj" : "Prenájom";
    if (data.izby) filled["Izby"] = data.izby;
    if (data.poschodie) filled["Poschodie"] = data.poschodie;
    if (data.balkon_plocha) filled["Balkón"] = data.balkon_plocha + " m²";
    if (data.loggia_plocha) filled["Loggia"] = data.loggia_plocha + " m²";
    if (data.pivnica_plocha) filled["Pivnica"] = data.pivnica_plocha + " m²";
    if (data.parcela) filled["Parcela"] = data.parcela;
    if (data.supisne_cislo) filled["Súp. číslo"] = data.supisne_cislo;
    if (data.energeticky_certifikat) filled["Energ. certifikát"] = data.energeticky_certifikat;
    if (data.vykurovanie) filled["Kúrenie"] = data.vykurovanie;
    if (data.mesacne_naklady) filled["Mesačné náklady"] = data.mesacne_naklady + " €";
    if (data.rok_kolaudacie) filled["Rok kolaudácie"] = data.rok_kolaudacie;
    if (data.rok_vystavby) filled["Rok výstavby"] = data.rok_vystavby;
    if (data.pravne_vady) filled["⚠ Právne vady"] = data.pravne_vady;
    if (data._ai) filled["AI"] = data._ai;
    setLvParsed(prev => ({ ...(prev || {}), ...filled }));

    // Auto-derive pozícia bytu
    let pozicia = "";
    if (data.poschodie) {
      const p = parseInt(data.poschodie, 10);
      if (p <= 0) pozicia = "prizemia";
      else if (p <= 2) pozicia = "nizsie-poschodie";
      else if (p <= 5) pozicia = "stredne-poschodie";
      else pozicia = "vyssie-poschodie";
    }

    const krajMatch = data.kraj ? KRAJE.find(k => k.toLowerCase().includes(data.kraj.toLowerCase().replace(" kraj", "").replace("ý", ""))) : undefined;
    const lokalitaParts = [data.ulica, data.obec, data.okres, data.kraj].filter(Boolean);
    const poznámky = [data.pravne_vady, data.poznamka, data.naklady_detail].filter(Boolean).join(". ");

    // Vykurovanie toggles
    const vykMap: Record<string, string> = {
      "centralne": "centralne", "centrálne": "centralne",
      "lokalne": "lokalne", "lokálne": "lokalne",
      "podlahove": "podlahove", "podlahové": "podlahove",
      "kozub": "kozub", "ine": "ine",
    };

    setF(prev => {
      const next = { ...prev };
      if (lvText) next.lv_text = lvText;
      // Základ
      next.obec = data.obec || prev.obec;
      next.okres = data.okres || prev.okres;
      next.kraj = (krajMatch || data.kraj || prev.kraj) as string;
      next.ulica_verejna = data.ulica || prev.ulica_verejna;
      next.lokalita = lokalitaParts.join(", ") || prev.lokalita;
      next.stat = "Slovensko";
      next.typ = ((data.typ && typMap[data.typ.toLowerCase()]) || prev.typ) as TypNehnutelnosti;
      next.kategoria = data.kategoria || prev.kategoria;
      next.cena = data.cena || prev.cena;
      next.plocha = data.plocha || prev.plocha;
      next.uzitkova_plocha = data.uzitkova_plocha || prev.uzitkova_plocha;
      next.izby = data.izby || prev.izby;
      next.poschodie = data.poschodie || prev.poschodie;
      next.vlastnictvo = data.vlastnictvo || prev.vlastnictvo;
      next.orientacia = data.orientacia || prev.orientacia;
      next.pozicia = pozicia || prev.pozicia;
      // Stav a materiál
      next.stav = (data.stav && (stavMap[data.stav.toLowerCase()] || data.stav)) || prev.stav;
      next.typ_budovy = (data.material && (materialMap[data.material.toLowerCase()] || data.material)) || prev.typ_budovy;
      next.energeticky_certifikat = data.energeticky_certifikat || prev.energeticky_certifikat;
      // Roky
      next.rok_vystavby = data.rok_vystavby || prev.rok_vystavby;
      next.rok_kolaudacie = data.rok_kolaudacie || prev.rok_kolaudacie;
      // Priestory — toggles
      if (data.balkon === "true") next.balkon = true;
      if (data.loggia === "true") next.loggia = true;
      if (data.terasa === "true") next.terasa = true;
      if (data.pivnica === "true") next.pivnica = true;
      if (data.garaz === "true") next.garaz = true;
      if (data.vytah === "true") next.vytah = true;
      if (data.klimatizacia === "true") next.vykurovanie = { ...next.vykurovanie, klimatizacia: true };
      // Priestory — plochy
      if (data.balkon_plocha) next.balkon_plocha = data.balkon_plocha;
      if (data.loggia_plocha) next.loggia_plocha = data.loggia_plocha;
      if (data.terasa_plocha) next.terasa_plocha = data.terasa_plocha;
      if (data.pivnica_plocha) next.pivnica_plocha = data.pivnica_plocha;
      if (data.parkovanie) next.parkovanie_typ = data.parkovanie;
      // Vykurovanie
      if (data.vykurovanie) {
        const vk = data.vykurovanie.toLowerCase();
        const key = vykMap[vk];
        if (key) next.vykurovanie = { ...next.vykurovanie, [key]: true };
      }
      // Náklady a právne
      next.mesacne_naklady = data.mesacne_naklady || prev.mesacne_naklady;
      next.naklady_detail = data.naklady_detail || prev.naklady_detail;
      next.pravne_vady = data.pravne_vady || prev.pravne_vady;
      // Siete
      if (data.inzinierske_siete === "true") next.inzinierske_siete = true;
      // ID
      next.interne_id = data.supisne_cislo ? `LV-${data.supisne_cislo}` : prev.interne_id;
      // Poznámky
      if (poznámky) next.poznamka_interna = prev.poznamka_interna ? `${prev.poznamka_interna}. ${poznámky}` : poznámky;
      return next;
    });
  }

  /* ── Parse LV ── */
  async function handleParseLV(textOverride?: string) {
    const lvText = textOverride ?? f.lv_text;
    if (!lvText.trim()) return;
    setParsingLV(true);
    try {
      const res = await globalThis.fetch("/api/parse-lv", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ lv_text: lvText }) });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      fillFormFromAI(data, lvText);
    } catch { setError("Nepodarilo sa spracovať dokument."); }
    setParsingLV(false);
  }

  /* ── Process any document via AI (znalecký posudok, zmluva, etc.) ── */
  async function handleProcessDoc(idx: number, docType?: string) {
    const doc = docs[idx];
    if (!doc?.text) return;
    setProcessingDoc(idx);
    try {
      const res = await globalThis.fetch("/api/parse-lv", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lv_text: doc.text, doc_type: docType || doc.type?.toLowerCase() }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      fillFormFromAI(data);
      const label = doc.type?.includes("✓") ? doc.type : `${doc.type} ✓`;
      setDocs(prev => prev.map((d, i) => i === idx ? { ...d, type: label } : d));
    } catch { setError("Nepodarilo sa spracovať dokument."); }
    setProcessingDoc(-1);
  }

  /* ── AI context ── */
  function buildContext(): string {
    const l: string[] = [];
    if (f.kategoria) l.push(`Ponuka: ${f.kategoria}`);
    if (f.typ) l.push(`Typ: ${f.typ}`);
    if (f.izby) l.push(`Izby: ${f.izby}`);
    if (f.stav) l.push(`Stav: ${f.stav}`);
    if (f.cena) l.push(`Cena: ${f.cena} €`);
    if (f.plocha) l.push(`Plocha: ${f.plocha} m²`);
    if (f.poschodie) l.push(`Poschodie: ${f.poschodie}`);
    const lok = [f.obec, f.okres, f.kraj].filter(Boolean).join(", ");
    if (lok) l.push(`Lokalita: ${lok}`);
    if (f.orientacia) l.push(`Orientácia: ${f.orientacia}`);
    if (f.vlastnictvo) l.push(`Vlastníctvo: ${f.vlastnictvo}`);
    if (f.popis) l.push(`Poznámka: ${f.popis}`);
    if (f.lv_text) l.push(`\nList vlastníctva:\n${f.lv_text}`);
    if (lvParsed) { l.push("\nExtrahované z LV:"); Object.entries(lvParsed).forEach(([k, v]) => l.push(`${k}: ${v}`)); }
    return l.join("\n");
  }

  async function handleGenerate() {
    const ctx = buildContext();
    if (!ctx.trim()) return;
    setGenerating(true);
    try {
      const res = await globalThis.fetch("/api/ai-writer", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nazov: `${f.typ} ${[f.obec, f.okres].filter(Boolean).join(", ")}`.trim(),
          typ: f.typ, lokalita: [f.obec, f.okres, f.kraj].filter(Boolean).join(", "),
          cena: Number(f.cena) || 0, plocha: Number(f.plocha) || null,
          izby: Number(f.izby) || null, stav: f.stav, popis: ctx,
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      const text = (data.emotivny || data.technicky || "").replace(/SEP_SEO\s*\[[^\]]*\]/g, "").replace(/SEP_TAGS\s*\[[^\]]*\]/g, "").trim();
      const seoMatch = (data.emotivny || "").match(/SEP_SEO\s*\[([^\]]+)\]/);
      const tagMatch = (data.emotivny || "").match(/SEP_TAGS\s*\[([^\]]+)\]/);
      setF(prev => ({
        ...prev, nazov: data.nazov || prev.nazov, text_popis: text, intro: data.kratky || prev.intro,
        seo_keywords: seoMatch ? seoMatch[1].trim() : generateSEO(prev),
        tagy: tagMatch ? tagMatch[1].trim() : prev.tagy,
      }));
      setTimeout(() => aiRef.current?.scrollIntoView({ behavior: "smooth", block: "center" }), 100);
    } catch { setError("Generovanie zlyhalo."); }
    setGenerating(false);
  }

  /* Auto-generate SEO keywords from form data */
  function generateSEO(form: typeof defaultForm): string {
    const parts: string[] = [];
    if (form.typ) parts.push(form.typ.replace(/-/g, " "));
    if (form.kategoria) parts.push(form.kategoria.replace(/-/g, " "));
    if (form.obec) parts.push(form.obec);
    if (form.okres) parts.push(form.okres);
    if (form.izby) parts.push(`${form.izby} izbový`);
    if (form.plocha) parts.push(`${form.plocha} m2`);
    if (form.stav) parts.push(form.stav);
    parts.push("nehnuteľnosť", "reality", "slovensko");
    return parts.filter(Boolean).join(", ");
  }

  async function handleRefine(instruction: string) {
    const msg = (instruction || chatInput).trim();
    if (!msg) return;
    setChatInput(""); setGenerating(true);
    try {
      const res = await globalThis.fetch("/api/ai-writer", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nazov: f.nazov || "Úprava", typ: f.typ,
          lokalita: [f.obec, f.okres, f.kraj].filter(Boolean).join(", "),
          cena: Number(f.cena) || 0, plocha: Number(f.plocha) || null,
          izby: Number(f.izby) || null, stav: f.stav,
          popis: `${buildContext()}\n\nPožiadavka: ${msg}\n\nAktuálny text:\n${f.text_popis}`,
        }),
      });
      const data = await res.json();
      const text = (data.emotivny || data.technicky || "").replace(/SEP_SEO\s*\[[^\]]*\]/g, "").replace(/SEP_TAGS\s*\[[^\]]*\]/g, "").trim();
      if (text) setF(prev => ({ ...prev, text_popis: text }));
    } catch { setError("Úprava zlyhala."); }
    setGenerating(false);
  }

  async function handleSave(publish: boolean) {
    if (!f.cena) { setError("Cena je povinná"); return; }
    setSaving(true); setError("");
    const { error: err } = await supabase.from("nehnutelnosti").insert({
      nazov: f.nazov.trim(), typ: f.typ,
      lokalita: [f.obec, f.okres, f.kraj].filter(Boolean).join(", ") || f.lokalita,
      cena: Number(f.cena), plocha: f.plocha ? Number(f.plocha) : null,
      izby: f.izby ? Number(f.izby) : null, poschodie: f.poschodie ? Number(f.poschodie) : null,
      stav: (f.stav || null) as StavNehnutelnosti | null,
      popis: f.text_popis || f.popis || null, url_inzercia: f.url_inzercia || null,
      intro: f.intro || null, text_popis: f.text_popis || null,
      zobrazovat_cenu: f.zobrazovat_cenu, zobrazovat_mapu: f.zobrazovat_mapu,
      zobrazovat_hypoteku: f.zobrazovat_hypoteku, so_zmluvou: f.so_zmluvou,
      projekt: f.projekt, specialne_oznacenie: f.specialne_oznacenie || null,
      seo_keywords: f.seo_keywords || null, stat: f.stat, kraj: f.kraj || null,
      okres: f.okres || null, obec: f.obec || null,
      ulica_privatna: f.ulica_privatna || null, makler: f.makler || null,
      interne_id: f.interne_id || null,
      provizia_hodnota: f.provizia_hodnota ? Number(f.provizia_hodnota) : null,
      provizia_typ: f.provizia_typ, poznamka_interna: f.poznamka_interna || null,
      orientacia: f.orientacia || null, pripojenie: f.pripojenie,
      typ_ceny: f.typ_ceny || null, tagy: f.tagy || null,
      vlastnictvo: f.vlastnictvo || null, text_k_cene: f.text_k_cene || null,
      cena_za_energie: f.cena_za_energie || null, exkluzivne: f.exkluzivne,
      url_virtualka: f.url_virtualka || null, vhodne_pre_studentov: f.vhodne_pre_studentov,
      video_url: f.video_url || null, kategoria: f.kategoria || null,
      export_portaly: publish ? f.export_portaly : {},
    });
    setSaving(false);
    if (err) { setError(err.message); return; }
    setSaved(true); setTimeout(() => setSaved(false), 3000);
    if (publish) { setF(defaultForm); onSaved?.(); }
  }

  const hasContent = photos.length > 0 || f.lv_text || docs.length > 0;
  const canGenerate = !!(f.typ || f.obec || f.lv_text);
  const allPortals = PORTALY.every(p => f.export_portaly[p.key]);

  return (
    <div style={{ maxWidth: "960px" }} onDragOver={e => e.preventDefault()} onDrop={e => e.preventDefault()}>

      {/* Header */}
      <div style={{ marginBottom: "28px" }}>
        <h1 style={{ fontSize: "26px", fontWeight: "700", color: "#374151", letterSpacing: "-0.03em" }}>Nový inzerát</h1>
        <p style={{ fontSize: "14px", color: "#9CA3AF", marginTop: "4px" }}>Nahraj súbory, skontroluj údaje a publikuj</p>
      </div>

      {/* ═══ GLOBAL PROGRESS ═══ */}
      <Progress active={!!uploadingFile} text={`Nahrávam ${uploadingFile}...`} />
      <Progress active={parsingLV && !uploadingFile} text="AI analyzuje List vlastníctva..." />
      <Progress active={processingDoc >= 0} text={`AI analyzuje dokument ${processingDoc >= 0 ? docs[processingDoc]?.name : ""}...`} />

      {/* ═══ DROP ZONE ═══ */}
      <div ref={dropRef}
        onDragOver={e => { e.preventDefault(); e.stopPropagation(); setDropOver(true); }}
        onDragEnter={e => { e.preventDefault(); e.stopPropagation(); setDropOver(true); }}
        onDragLeave={e => { e.preventDefault(); e.stopPropagation(); if (!dropRef.current?.contains(e.relatedTarget as Node)) setDropOver(false); }}
        onDrop={handleDrop}
        style={{ ...s.card, padding: 0, overflow: "hidden", border: dropOver ? "2px solid #3B82F6" : "2px dashed #E5E7EB", background: dropOver ? "#EFF6FF" : "#fff", transition: "all 0.2s" }}>
        <input ref={fileRef} type="file" multiple accept="image/*,.pdf,.doc,.docx,.txt" style={{ display: "none" }}
          onChange={e => { if (e.target.files?.length) handleFiles(e.target.files); e.target.value = ""; }} />

        {!hasContent ? (
          <div onClick={() => fileRef.current?.click()} style={{ padding: "48px 24px", textAlign: "center", cursor: "pointer" }}>
            {dropOver
              ? <><div style={{ fontSize: "32px", marginBottom: "8px" }}>⬇️</div><div style={{ fontSize: "16px", fontWeight: "600", color: "#3B82F6" }}>Pusť súbory sem</div></>
              : <><div style={{ width: "56px", height: "56px", borderRadius: "16px", background: "#F3F4F6", margin: "0 auto 12px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "24px" }}>+</div><div style={{ fontSize: "15px", fontWeight: "600", color: "#374151" }}>Klikni alebo pretiahni súbory</div><div style={{ fontSize: "13px", color: "#9CA3AF", marginTop: "6px" }}>Fotky · List vlastníctva · Zmluvy — systém roztriedí automaticky</div></>}
          </div>
        ) : (
          <div style={{ padding: "20px" }}>
            {photos.length > 0 && (
              <div style={{ marginBottom: "16px" }}>
                <div style={{ fontSize: "11px", fontWeight: "600", color: "#9CA3AF", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: "10px" }}>Fotky ({photos.length})</div>
                <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                  {photos.map((p, i) => (
                    <div key={i} style={{ width: "72px", height: "72px", borderRadius: "10px", overflow: "hidden", position: "relative", background: "#F3F4F6" }}>
                      <img src={p.url} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                      <button onClick={() => { URL.revokeObjectURL(p.url); setPhotos(prev => prev.filter((_, j) => j !== i)); }}
                        style={{ position: "absolute", top: "3px", right: "3px", width: "18px", height: "18px", borderRadius: "9px", border: "none", background: "rgba(0,0,0,0.45)", color: "#fff", fontSize: "11px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>×</button>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {f.lv_text && (
              <div style={{ marginBottom: "16px" }}>
                <div style={{ fontSize: "11px", fontWeight: "600", color: "#9CA3AF", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: "10px", display: "flex", alignItems: "center", gap: "6px" }}>
                  List vlastníctva {lvParsed && <span style={{ color: "#10B981" }}>✓</span>}
                </div>
                {lvParsed && (
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "4px", marginBottom: "8px" }}>
                    {Object.entries(lvParsed).map(([k, v]) => (
                      <span key={k} style={{ padding: "3px 8px", borderRadius: "6px", fontSize: "11px", background: "#F3F4F6", color: "#374151" }}>{k}: <strong>{v}</strong></span>
                    ))}
                  </div>
                )}
                <details><summary style={{ fontSize: "11px", color: "#9CA3AF", cursor: "pointer" }}>Zobraziť LV text</summary>
                  <textarea style={{ ...s.input, marginTop: "6px", minHeight: "60px", resize: "vertical", fontSize: "12px" }} value={f.lv_text} onChange={e => set("lv_text", e.target.value)} />
                </details>
              </div>
            )}
            {docs.length > 0 && (
              <div style={{ marginBottom: "16px" }}>
                <div style={{ fontSize: "11px", fontWeight: "600", color: "#9CA3AF", textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: "8px" }}>Dokumenty ({docs.length})</div>
                {docs.map((d, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: "8px", padding: "6px 10px", borderRadius: "8px", background: "#F9FAFB", fontSize: "12px", marginBottom: "4px" }}>
                    <span>📄</span><span style={{ flex: 1 }}>{d.name}</span><span style={{ color: "#9CA3AF" }}>{(d.size / 1024).toFixed(0)} KB</span>
                    {d.text && d.type !== "PDF ✓" && (
                      <button onClick={() => handleProcessDoc(i)} disabled={processingDoc === i}
                        style={{ padding: "3px 10px", borderRadius: "6px", border: "1px solid #3B82F6", background: processingDoc === i ? "#EFF6FF" : "#fff", color: "#3B82F6", fontSize: "11px", fontWeight: "500", cursor: processingDoc === i ? "wait" : "pointer", whiteSpace: "nowrap" }}>
                        {processingDoc === i ? "Analyzujem..." : "⚡ AI"}
                      </button>
                    )}
                    {d.type === "PDF ✓" && <span style={{ color: "#10B981", fontSize: "11px", fontWeight: "500" }}>✓ Spracované</span>}
                    <button onClick={() => setDocs(prev => prev.filter((_, j) => j !== i))} style={{ background: "none", border: "none", color: "#9CA3AF", cursor: "pointer" }}>×</button>
                  </div>
                ))}
              </div>
            )}
            <button onClick={() => fileRef.current?.click()} style={{ width: "100%", padding: "10px", borderRadius: "10px", border: "1.5px dashed #D1D5DB", background: "transparent", fontSize: "13px", color: "#6B7280", cursor: "pointer" }}>+ Pridať súbory</button>
          </div>
        )}
      </div>

      {/* Ctrl+V LV */}
      {!f.lv_text && (
        <div style={{ ...s.card, padding: "14px 20px" }}>
          <textarea style={{ ...s.input, minHeight: "56px", resize: "none", fontSize: "13px" }}
            placeholder="Alebo vlož text z LV priamo sem (Ctrl+V)..."
            value={f.lv_text} onChange={e => set("lv_text", e.target.value)}
            onPaste={e => { const t = e.clipboardData.getData("text"); if (t.trim().length > 30) setTimeout(() => handleParseLV(t), 100); }} />
        </div>
      )}

      {/* ═══ MAIN GRID ═══ */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 260px", gap: "12px", alignItems: "start" }}>
        <div>
          {/* Kategória */}
          <div style={s.card}>
            <div style={s.g2}>
              <div>
                <label style={s.label}>Kategória</label>
                <select style={s.select} value={f.typ} onChange={e => set("typ", e.target.value)}>
                  <option value="">— vyberte —</option>
                  <optgroup label="Byty"><option value="garsonka">Garsónka</option><option value="dvojgarsonka">Dvojgarsónka</option><option value="1-izbovy-byt">1-izbový byt</option><option value="2-izbovy-byt">2-izbový byt</option><option value="3-izbovy-byt">3-izbový byt</option><option value="4-izbovy-byt">4-izbový byt</option><option value="5-izbovy-byt">5 a viac izbový byt</option><option value="loft">Loft</option><option value="mezonet">Mezonet</option><option value="apartman">Rekreačný apartmán</option></optgroup>
                  <optgroup label="Domy"><option value="rodinny-dom">Rodinný dom</option><option value="chata">Chata</option><option value="vidiecky-dom">Vidiecky dom</option><option value="farmarska-usadlost">Farmárska usadlosť</option><option value="mobilny-dom">Mobilný dom</option><option value="hausbot">Hausbót</option><option value="zrub">Zrub</option><option value="zahradny-domcek">Záhradný domček</option></optgroup>
                  <optgroup label="Pozemky"><option value="pozemok-rd">Pre rodinné domy</option><option value="polnohospodarska-poda">Poľnohospodárska pôda</option><option value="zahrada">Záhrada</option><option value="komercna-zona">Komerčná zóna</option><option value="vinice">Vinice</option><option value="pozemok-rekreacia">Na rekreáciu</option><option value="pozemok-vystavba">Na výstavbu</option><option value="stavebny-pozemok">Stavebný pozemok</option><option value="pozemok-obcianska">Občianska vybavenosť</option><option value="priemyselna-zona">Priemyselná zóna</option><option value="zmiesana-zona">Zmiešaná zóna</option><option value="sad">Sad</option><option value="luky-pasienky">Lúky a pasienky</option><option value="orna-poda">Orná pôda</option><option value="les">Les</option><option value="jazero">Jazero</option></optgroup>
                  <optgroup label="Objekty"><option value="komercny-objekt">Komerčný objekt</option><option value="vyrobne-zariadenie">Výrobné zariadenie</option><option value="kancelarie">Kancelárie</option><option value="restauracia">Reštaurácia</option><option value="sklad">Sklad</option><option value="hotel-penzion">Hotel - penzión</option><option value="polyfunkcna-budova">Polyfunkčná budova</option><option value="servisne-zariadenie">Servisné zariadenie</option><option value="chov-zvierat">Chov zvierat</option><option value="kupele">Kúpele</option><option value="historicky-objekt">Historický objekt</option><option value="sportovy-objekt">Športový objekt</option><option value="mala-elektraren">Malá elektráreň</option><option value="pumpa">Pumpa</option></optgroup>
                </select>
              </div>
              <div>
                <label style={s.label}>Typ ponuky</label>
                <select style={s.select} value={f.kategoria} onChange={e => set("kategoria", e.target.value)}>
                  <option value="">— vyberte —</option>
                  <optgroup label="Predaj"><option value="na-predaj">NA PREDAJ!</option><option value="pripravujeme-predaj">PRIPRAVUJEME na predaj</option><option value="iba-u-nas-predaj">IBA U NÁS! (predaj)</option></optgroup>
                  <optgroup label="Nájom"><option value="na-najom">NA NÁJOM!</option><option value="pripravujeme-najom">PRIPRAVUJEME na nájom</option><option value="iba-u-nas-najom">IBA U NÁS! (nájom)</option></optgroup>
                </select>
              </div>
            </div>
          </div>

          {/* Základné údaje */}
          <div style={s.card}>
            <div style={s.title}>Základné údaje</div>
            {f.nazov && (
              <div style={{ marginBottom: "14px", padding: "8px 12px", background: "#F0F9FF", borderRadius: "8px", fontSize: "13px" }}>
                <span style={{ color: "#3B82F6", fontWeight: "500" }}>Názov:</span> {f.nazov}
              </div>
            )}
            <div style={{ ...s.g2, marginBottom: "12px" }}>
              <div>
                <label style={s.label}>Cena (€)</label>
                <input style={s.input} type="number" placeholder="150 000" value={f.cena}
                  onChange={e => set("cena", e.target.value)}
                  onBlur={e => { const b = toBataCena(e.target.value); if (b !== e.target.value && b !== "NaN") set("cena", b); }} />
              </div>
              <div><label style={s.label}>Výmera (m²)</label><input style={s.input} type="number" placeholder="65" value={f.plocha} onChange={e => set("plocha", e.target.value)} /></div>
            </div>
            <div style={s.g2}>
              <div><label style={s.label}>Maklér</label><select style={s.select} value={f.makler} onChange={e => set("makler", e.target.value)}><option value="Aleš Machovič">Aleš Machovič</option></select></div>
              <div><label style={s.label}>Interné ID</label><input style={s.input} value={f.interne_id} onChange={e => set("interne_id", e.target.value)} /></div>
            </div>
          </div>

          {/* Rozšírené vlastnosti */}
          <div style={s.card}>
            <div style={s.title}>Rozšírené vlastnosti</div>
            <div style={{ ...s.g2, marginBottom: "12px" }}>
              <div><label style={s.label}>Úžitková plocha (m²)</label><input style={s.input} type="number" value={f.uzitkova_plocha} onChange={e => set("uzitkova_plocha", e.target.value)} /></div>
              <div><label style={s.label}>Zastavaná plocha (m²)</label><input style={s.input} type="number" value={f.zastavana_plocha} onChange={e => set("zastavana_plocha", e.target.value)} /></div>
            </div>
            <div style={{ ...s.g2, marginBottom: "12px" }}>
              <div><label style={s.label}>Podlahová plocha (m²)</label><input style={s.input} type="number" value={f.podlahova_plocha} onChange={e => set("podlahova_plocha", e.target.value)} /></div>
              <div><label style={s.label}>Skladová plocha (m²)</label><input style={s.input} type="number" value={f.skladova_plocha} onChange={e => set("skladova_plocha", e.target.value)} /></div>
            </div>
            <div style={{ ...s.g2, marginBottom: "12px" }}>
              <div><label style={s.label}>Stav</label>
                <select style={s.select} value={f.stav} onChange={e => set("stav", e.target.value)}>
                  <option value="">—</option>
                  <option value="novostavba">Novostavba</option>
                  <option value="uplne-prerobeny">Úplne prerobený</option>
                  <option value="ciastocne-prerobeny">Čiastočne prerobený</option>
                  <option value="povodny-stav">Pôvodný stav</option>
                  <option value="vo-faze-projektovania">Vo fáze projektovania</option>
                  <option value="vo-vystavbe">Vo výstavbe</option>
                  <option value="urcene-na-demolaciu">Určené na demoláciu</option>
                </select>
              </div>
              <div><label style={s.label}>Energetický certifikát</label>
                <select style={s.select} value={f.energeticky_certifikat} onChange={e => set("energeticky_certifikat", e.target.value)}>
                  <option value="">—</option>{["A0","A1","A","B","C","D","E","F","G"].map(v => <option key={v} value={v}>{v}</option>)}
                </select>
              </div>
            </div>
            <div style={{ ...s.g2, marginBottom: "12px" }}>
              <div><label style={s.label}>Typ budovy</label>
                <select style={s.select} value={f.typ_budovy} onChange={e => set("typ_budovy", e.target.value)}>
                  <option value="">—</option>
                  <option value="panelova">Panelová</option><option value="tehlova">Tehlová</option>
                  <option value="zmiešaná">Zmiešaná</option><option value="montovana">Montovaná</option>
                  <option value="drevena">Drevená</option><option value="ina">Iná</option>
                </select>
              </div>
              <div><label style={s.label}>Typ výbavy</label>
                <select style={s.select} value={f.typ_vybavy} onChange={e => set("typ_vybavy", e.target.value)}>
                  <option value="">—</option>
                  <option value="uplne-zariadeny">Úplne zariadený</option>
                  <option value="ciastocne-zariadeny">Čiastočne zariadený</option>
                  <option value="nezariadeny">Nezariadený</option>
                </select>
              </div>
            </div>
          </div>

          {/* Priestory */}
          <div style={s.card}>
            <div style={s.title}>Priestory a vybavenie</div>
            <div style={{ ...s.g2, marginBottom: "12px" }}>
              <div><label style={s.label}>Pozícia bytu</label>
                <select style={s.select} value={f.pozicia} onChange={e => set("pozicia", e.target.value)}>
                  <option value="">—</option><option value="vyssie-poschodie">Vyššie poschodie</option><option value="stredne-poschodie">Stredné poschodie</option><option value="nizsie-poschodie">Nižšie poschodie</option><option value="prizemia">Prízemie</option><option value="suteren">Suterén</option><option value="mezonet">Mezonet</option>
                </select>
              </div>
              <div><label style={s.label}>Poschodie</label><input style={s.input} type="number" value={f.poschodie} onChange={e => set("poschodie", e.target.value)} /></div>
            </div>
            <div style={{ ...s.g3, marginBottom: "12px" }}>
              {[["balkon","Balkón"],["loggia","Loggia"],["terasa","Terasa"],["garaz","Garáž"],["pivnica","Pivnica"],["vytah","Výťah"]].map(([k,l]) => (
                <Tog key={k} on={(f as Record<string, unknown>)[k] as boolean} set={v => set(k, v)} label={l} />
              ))}
            </div>
            <div style={{ ...s.g3, marginBottom: "12px" }}>
              {[["verejne_parkovanie","Verejné park."],["sukromne_parkovanie","Súkromné park."],["spajza","Špajza"],["sklad_toggle","Sklad"],["dielna","Dielňa"]].map(([k,l]) => (
                <Tog key={k} on={(f as Record<string, unknown>)[k] as boolean} set={v => set(k, v)} label={l} />
              ))}
            </div>

            {/* Detail priestorov ak zapnuté */}
            {(f.balkon || f.loggia || f.terasa || f.pivnica || f.garaz) && (
              <div style={{ ...s.g2, marginTop: "8px", paddingTop: "12px", borderTop: "1px solid #F3F4F6" }}>
                {f.balkon && <div><label style={s.label}>Balkón plocha (m²)</label><input style={s.input} type="number" value={f.balkon_plocha} onChange={e => set("balkon_plocha", e.target.value)} /></div>}
                {f.loggia && <><div><label style={s.label}>Loggia plocha (m²)</label><input style={s.input} type="number" value={f.loggia_plocha} onChange={e => set("loggia_plocha", e.target.value)} /></div><div><label style={s.label}>Počet loggií</label><input style={s.input} type="number" value={f.loggia_pocet} onChange={e => set("loggia_pocet", e.target.value)} /></div></>}
                {f.terasa && <div><label style={s.label}>Terasa plocha (m²)</label><input style={s.input} type="number" value={f.terasa_plocha} onChange={e => set("terasa_plocha", e.target.value)} /></div>}
                {f.pivnica && <><div><label style={s.label}>Pivnica plocha (m²)</label><input style={s.input} type="number" value={f.pivnica_plocha} onChange={e => set("pivnica_plocha", e.target.value)} /></div><div><label style={s.label}>Počet pivníc</label><input style={s.input} type="number" value={f.pivnica_pocet} onChange={e => set("pivnica_pocet", e.target.value)} /></div></>}
                {f.garaz && <div><label style={s.label}>Typ parkovania</label>
                  <select style={s.select} value={f.parkovanie_typ} onChange={e => set("parkovanie_typ", e.target.value)}>
                    <option value="">—</option><option value="garaz">Garáž</option><option value="statie">Parkovacie státie</option><option value="ine">Iné</option>
                  </select>
                </div>}
              </div>
            )}
          </div>

          {/* Roky + poschodia */}
          <div style={s.card}>
            <div style={s.title}>História budovy</div>
            <div style={{ ...s.g3, marginBottom: "12px" }}>
              <div><label style={s.label}>Rok výstavby</label><input style={s.input} type="number" placeholder="1985" value={f.rok_vystavby} onChange={e => set("rok_vystavby", e.target.value)} /></div>
              <div><label style={s.label}>Rok rekonštrukcie</label><input style={s.input} type="number" value={f.rok_rekonstrukcie} onChange={e => set("rok_rekonstrukcie", e.target.value)} /></div>
              <div><label style={s.label}>Rok kolaudácie</label><input style={s.input} type="number" value={f.rok_kolaudacie} onChange={e => set("rok_kolaudacie", e.target.value)} /></div>
            </div>
            <div style={s.g2}>
              <div><label style={s.label}>Poschodia vyššie</label><input style={s.input} type="number" value={f.poschodia_vyssie} onChange={e => set("poschodia_vyssie", e.target.value)} /></div>
              <div><label style={s.label}>Poschodia nižšie</label><input style={s.input} type="number" value={f.poschodia_nizsie} onChange={e => set("poschodia_nizsie", e.target.value)} /></div>
            </div>
          </div>

          {/* Vykurovanie */}
          <div style={s.card}>
            <div style={s.title}>Vykurovanie</div>
            <div style={s.g3}>
              {[["centralne","Centrálne"],["podlahove","Podlahové"],["lokalne","Lokálne"],["kozub","Kozub"],["klimatizacia","Klimatizácia"],["emitory","Emitory"],["ine","Iné"]].map(([k,l]) => (
                <Tog key={k} on={f.vykurovanie[k] ?? false} set={v => setVyk(k, v)} label={l} />
              ))}
            </div>
          </div>

          {/* Ďalšie vlastnosti */}
          <div style={s.card}>
            <div style={s.title}>Ďalšie vlastnosti</div>
            <div style={{ ...s.g2, marginBottom: "12px" }}>
              <div><label style={s.label}>Orientácia</label>
                <select style={s.select} value={f.orientacia} onChange={e => set("orientacia", e.target.value)}>
                  <option value="">—</option><option value="S">Sever</option><option value="J">Juh</option><option value="V">Východ</option><option value="Z">Západ</option><option value="SV">SV</option><option value="SZ">SZ</option><option value="JV">JV</option><option value="JZ">JZ</option>
                </select>
              </div>
              <Tog on={f.inzinierske_siete} set={v => set("inzinierske_siete", v)} label="Inžinierske siete" />
            </div>
            <div style={{ fontSize: "13px", fontWeight: "500", color: "#374151", marginBottom: "8px" }}>Komunikačné pripojenie</div>
            <div style={s.g3}>
              {[["telefon","Telefón"],["internet","Internet"],["satelit","Satelit"],["kablova_tv","Káblová TV"],["opticka_siet","Optická sieť"],["ine","Iné"]].map(([k,l]) => (
                <Tog key={k} on={f.pripojenie[k] ?? false} set={v => setPr(k, v)} label={l} />
              ))}
            </div>
          </div>

          {/* 💶 Mesačné náklady */}
          <div style={s.card}>
            <div style={s.title}>Mesačné náklady</div>
            <div style={{ ...s.g2, marginBottom: "12px" }}>
              <div><label style={s.label}>Náklady celkom (€/mes)</label><input style={s.input} type="number" placeholder="250" value={f.mesacne_naklady} onChange={e => set("mesacne_naklady", e.target.value)} /></div>
              <div><label style={s.label}>Cena za energie (€/mes)</label><input style={s.input} type="number" value={f.cena_za_energie} onChange={e => set("cena_za_energie", e.target.value)} /></div>
            </div>
            {f.naklady_detail && (
              <div style={{ padding: "8px 12px", background: "#F0F9FF", borderRadius: "8px", fontSize: "12px", color: "#1D4ED8" }}>
                <span style={{ fontWeight: "600" }}>Rozpis:</span> {f.naklady_detail}
              </div>
            )}
          </div>

          {/* ⚠️ Právne vady */}
          {f.pravne_vady && (
            <div style={{ ...s.card, borderLeft: "3px solid #F59E0B" }}>
              <div style={{ fontSize: "13px", fontWeight: "600", color: "#D97706", marginBottom: "8px" }}>⚠ Právne vady a ťarchy</div>
              <textarea style={{ ...s.input, resize: "vertical", minHeight: "60px", fontSize: "13px" }} value={f.pravne_vady} onChange={e => set("pravne_vady", e.target.value)} />
            </div>
          )}

          {/* Video */}
          <div style={s.card}>
            <div style={s.title}>Video</div>
            <input style={s.input} placeholder="https://youtube.com/..." value={f.video_url} onChange={e => set("video_url", e.target.value)} />
          </div>

          {/* ═══ AI WRITER — NA SPODKU ═══ */}
          <div ref={aiRef} style={{
            ...s.card, padding: 0, overflow: "hidden",
            background: generating ? "#F3F4F6" : "#fff", transition: "background 0.3s",
          }}>
            <div style={{ padding: "18px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: f.text_popis ? "1px solid #E5E7EB" : "none" }}>
              <div>
                <div style={{ fontSize: "15px", fontWeight: "600", color: "#374151", display: "flex", alignItems: "center", gap: "8px" }}>
                  AI Writer
                  {generating && <span style={{ display: "inline-flex", alignItems: "center", gap: "6px", fontSize: "12px", fontWeight: "500", color: "#3B82F6", background: "#EFF6FF", padding: "2px 10px", borderRadius: "10px" }}><span style={{ width: "8px", height: "8px", borderRadius: "4px", background: "#3B82F6", animation: "pulse 1s ease-in-out infinite" }} />Generujem...</span>}
                </div>
                <div style={{ fontSize: "12px", color: "#9CA3AF", marginTop: "2px" }}>
                  {[f.typ, f.izby ? `${f.izby}-izb.` : "", f.plocha ? `${f.plocha} m²` : "", f.cena ? `${f.cena} €` : "", [f.obec, f.okres].filter(Boolean).join(", ")].filter(Boolean).join(" · ") || "Vyplň údaje vyššie"}
                </div>
              </div>
              <button onClick={handleGenerate} disabled={generating || !canGenerate}
                style={{ padding: "8px 18px", borderRadius: "8px", border: "none", background: generating ? "transparent" : "#374151", color: generating ? "transparent" : "#fff", fontSize: "12px", fontWeight: "600", cursor: generating ? "default" : "pointer" }}>
                {f.text_popis ? "Pregenerovať" : "Napísať text"}
              </button>
            </div>

            {!f.text_popis && !generating && (
              <div style={{ padding: "0 20px 16px" }}>
                <textarea style={{ ...s.input, resize: "none", height: "44px", fontSize: "13px" }}
                  placeholder="Poznámka pre AI — zariadený, nové podlahy, výhľad na Dunaj..."
                  value={f.popis} onChange={e => set("popis", e.target.value)} />
              </div>
            )}

            {generating && !f.text_popis && (
              <div style={{ padding: "32px 24px", textAlign: "center" }}>
                <div style={{ display: "flex", justifyContent: "center", gap: "6px", marginBottom: "12px" }}>
                  {[0, 1, 2].map(i => <div key={i} style={{ width: "8px", height: "8px", borderRadius: "4px", background: "#3B82F6", animation: `bounce 1.2s ease-in-out ${i * 0.15}s infinite` }} />)}
                </div>
                <div style={{ fontSize: "14px", fontWeight: "500", color: "#374151" }}>AI píše text inzerátu</div>
                <div style={{ fontSize: "12px", color: "#9CA3AF", marginTop: "4px" }}>Gemini skúma lokalitu · Claude a GPT píšu text</div>
              </div>
            )}

            {f.text_popis && (
              <div style={{ background: generating ? "#F9FAFB" : "transparent", transition: "background 0.3s" }}>
                <div style={{ padding: "16px 20px 0" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                    <span style={s.label}>Intro</span><span style={{ fontSize: "11px", color: "#D1D5DB" }}>{f.intro.length}/160</span>
                  </div>
                  <textarea style={{ ...s.input, resize: "none", height: "44px", fontSize: "13px", background: generating ? "#EBEDF0" : "#F9FAFB" }} maxLength={160} value={f.intro} onChange={e => set("intro", e.target.value)} readOnly={generating} />
                </div>

                <div style={{ padding: "12px 20px 0" }}>
                  <label style={s.label}>Popis inzerátu</label>
                  <textarea style={{ ...s.input, resize: "vertical", minHeight: "180px", fontSize: "14px", lineHeight: 1.7, background: generating ? "#EBEDF0" : "#F9FAFB" }} value={f.text_popis} onChange={e => set("text_popis", e.target.value)} readOnly={generating} />
                </div>

                <div style={{ padding: "12px 20px", display: "flex", gap: "6px", flexWrap: "wrap" }}>
                  {[{ l: "✂ Skrátiť", c: "Skráť text" }, { l: "＋ Rozšíriť", c: "Rozšír text, pridaj detaily" }, { l: "🎩 Formálnejšie", c: "Formálnejší tón" }, { l: "😊 Priateľskejšie", c: "Priateľskejší, ľudskejší tón" }].map(a => (
                    <button key={a.l} disabled={generating} onClick={() => handleRefine(a.c)}
                      style={{ padding: "6px 14px", borderRadius: "8px", fontSize: "12px", fontWeight: "500", border: "1.5px solid #E5E7EB", background: generating ? "#F3F4F6" : "#fff", color: "#374151", cursor: generating ? "default" : "pointer", opacity: generating ? 0.5 : 1 }}>{a.l}</button>
                  ))}
                </div>

                <div style={{ padding: "4px 20px 16px", display: "flex", gap: "6px" }}>
                  <input value={chatInput} onChange={e => setChatInput(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && !generating && handleRefine("")}
                    placeholder="Uprav text — napr. pridaj výhľad, zmeň tón..."
                    style={{ ...s.input, flex: 1, fontSize: "12px", padding: "8px 12px" }} />
                  <button onClick={() => handleRefine("")} disabled={generating || !chatInput.trim()}
                    style={{ padding: "8px 14px", borderRadius: "10px", border: "none", background: chatInput.trim() ? "#374151" : "#E5E7EB", color: chatInput.trim() ? "#fff" : "#9CA3AF", fontSize: "12px", fontWeight: "600", cursor: "pointer", flexShrink: 0 }}>Upraviť</button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ═══ SIDEBAR ═══ */}
        <div style={{ display: "flex", flexDirection: "column", gap: "12px", position: "sticky", top: "80px" }}>
          {/* Zobrazenie */}
          <div style={s.card}>
            <div style={s.title}>Zobrazenie</div>
            <Tog on={f.zobrazovat_cenu} set={v => set("zobrazovat_cenu", v)} label="Cena" />
            <Tog on={f.zobrazovat_mapu} set={v => set("zobrazovat_mapu", v)} label="Mapa" />
            <Tog on={f.zobrazovat_hypoteku} set={v => set("zobrazovat_hypoteku", v)} label="Hypokalkulačka" />
            <div style={{ borderTop: "1px solid #F3F4F6", marginTop: "6px", paddingTop: "6px" }}>
              <Tog on={f.so_zmluvou} set={v => set("so_zmluvou", v)} label="So zmluvou" />
              <Tog on={f.projekt} set={v => set("projekt", v)} label="Projekt" />
            </div>
          </div>

          {/* Export — menší, v sidebar */}
          <div style={s.card}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "10px" }}>
              <div style={{ fontSize: "13px", fontWeight: "600", color: "#374151" }}>Portály</div>
              <button onClick={toggleAllPortals} style={{ fontSize: "11px", color: "#3B82F6", background: "none", border: "none", cursor: "pointer", fontWeight: "500" }}>
                {allPortals ? "Zrušiť" : "Všetky"}
              </button>
            </div>
            {PORTALY.map(p => (
              <Tog key={p.key} on={f.export_portaly[p.key] ?? false} set={v => setEx(p.key, v)} label={p.label} />
            ))}
          </div>

          {/* SEO */}
          <div style={s.card}>
            <div style={s.title}>SEO</div>
            <div style={{ marginBottom: "10px" }}>
              <label style={s.label}>Označenie</label>
              <input style={s.input} placeholder="top" value={f.specialne_oznacenie} onChange={e => set("specialne_oznacenie", e.target.value)} />
            </div>
            <div>
              <label style={s.label}>Keywords <span style={{ color: "#9CA3AF", fontWeight: "400" }}>· AI doplní</span></label>
              <input style={s.input} placeholder="doplní AI automaticky" value={f.seo_keywords} onChange={e => set("seo_keywords", e.target.value)} />
            </div>
          </div>

          {/* Privátne */}
          <div style={{ ...s.card, borderLeft: "3px solid #EF4444" }}>
            <div style={{ fontSize: "13px", fontWeight: "600", color: "#EF4444", marginBottom: "12px" }}>Privátne</div>
            <label style={s.label}>Provízia</label>
            <div style={{ display: "flex", gap: "6px", marginBottom: "8px" }}>
              {["EUR", "%"].map(t => (
                <button key={t} onClick={() => set("provizia_typ", t)} style={{ padding: "5px 14px", borderRadius: "6px", fontSize: "12px", fontWeight: "600", cursor: "pointer", border: f.provizia_typ === t ? "1.5px solid #111" : "1.5px solid #E5E7EB", background: f.provizia_typ === t ? "#374151" : "#fff", color: f.provizia_typ === t ? "#fff" : "#6B7280" }}>{t}</button>
              ))}
            </div>
            <input style={{ ...s.input, marginBottom: "10px" }} type="number" value={f.provizia_hodnota} onChange={e => set("provizia_hodnota", e.target.value)} />
            <label style={s.label}>Poznámka</label>
            <textarea style={{ ...s.input, resize: "none", height: "60px", fontSize: "12px" }} value={f.poznamka_interna} onChange={e => set("poznamka_interna", e.target.value)} />
          </div>
        </div>
      </div>

      {/* Notifications */}
      {error && (
        <div style={{ margin: "12px 0", padding: "10px 16px", background: "#FEF2F2", borderRadius: "10px", fontSize: "13px", color: "#DC2626", display: "flex", justifyContent: "space-between" }}>
          {error}<button onClick={() => setError("")} style={{ background: "none", border: "none", color: "#DC2626", cursor: "pointer", fontWeight: "600" }}>×</button>
        </div>
      )}
      {saved && <div style={{ margin: "12px 0", padding: "10px 16px", background: "#F0FDF4", borderRadius: "10px", fontSize: "13px", color: "#16A34A" }}>✓ Uložené</div>}

      {/* Bottom bar */}
      <div style={{ position: "sticky", bottom: 0, background: "#fff", borderTop: "1px solid #F3F4F6", padding: "14px 0", marginTop: "20px", display: "flex", gap: "8px", justifyContent: "flex-end" }}>
        <button onClick={() => { setF(defaultForm); onCancel?.(); }} style={{ padding: "9px 18px", background: "#fff", border: "1.5px solid #E5E7EB", borderRadius: "8px", fontSize: "13px", color: "#6B7280", cursor: "pointer" }}>Zahodiť</button>
        <button onClick={() => handleSave(false)} disabled={saving} style={{ padding: "9px 22px", background: "#fff", border: "1.5px solid #E5E7EB", borderRadius: "8px", fontSize: "13px", fontWeight: "600", color: "#374151", cursor: "pointer" }}>Uložiť</button>
        <button onClick={() => handleSave(true)} disabled={saving} style={{ padding: "9px 24px", background: "#374151", color: "#fff", border: "none", borderRadius: "8px", fontSize: "13px", fontWeight: "600", cursor: saving ? "wait" : "pointer" }}>{saving ? "..." : "Publikovať"}</button>
      </div>
    </div>
  );
}
